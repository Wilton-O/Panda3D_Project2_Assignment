''' Wilton Oliver | CSCI 1551 - Concepts 3D Games Engines | 2026-02-21 '''


# Import general app dependencies
from direct.showbase.ShowBase import ShowBase
from panda3d.core import *
import DefensePaths as defensePaths
import SpaceJamClasses as spaceJamClasses


# Create 'main' class for in-app code execution
class mySpaceJam(ShowBase):
    # Define what will execute as soon as the app is run
    def __init__(self):
        # Create game window
        ShowBase.__init__(self)
 

        # Create the scene - skybox, planets, enemies, player base, player model, etc.    
        # Load, Render the 'universe' skybox
        self.Universe = spaceJamClasses.Universe(self.loader, "Assets/Universe/Universe/Universe.x", self.render, 'Universe', "Assets/Universe/universe-texture.jpg", (0, 0, 0), 15000)

        # Load, Render Planet 1 - "Solterra"
        self.Planet1 = spaceJamClasses.Planet(self.loader, "Assets/Planets/protoPlanet.x", self.render, 'Planet1', "Assets/Planets/molten-planet [solterra].jpg", (200, 5000, 89), 250)

        # Load, Render Planet 2 - "Dusk"
        self.Planet2 = spaceJamClasses.Planet(self.loader, "Assets/Planets/protoPlanet.x", self.render, 'Planet2', "Assets/Planets/dust-planet [dusk].jpg", (5300, 5750, 550), 500)

        # Load, Render Planet 3 - "Atla"
        self.Planet3 = spaceJamClasses.Planet(self.loader, "Assets/Planets/protoPlanet.x", self.render, 'Planet3', "Assets/Planets/water-planet [atla].jpg", (-5030, 6500, -2900), 1250)

        # Load, Render Planet 4 - "Gamma"
        self.Planet4 = spaceJamClasses.Planet(self.loader, "Assets/Planets/protoPlanet.x", self.render, 'Planet4', "Assets/Planets/gem-planet [gamma].jpg", (-1700, 8000, 3275), 1500)

        # Load, Render Planet 5 - "Hearth"
        self.Planet5 = spaceJamClasses.Planet(self.loader, "Assets/Planets/protoPlanet.x", self.render, 'Planet5', "Assets/Planets/dry-planet [hearth].jpg", (3500, 1500, -2051), 890)

        # Load, Render Planet 6 - "Aero"
        self.Planet6 = spaceJamClasses.Planet(self.loader, "Assets/Planets/protoPlanet.x", self.render, 'Planet6', "Assets/Planets/cloud-planet [aero].jpg", (520, 0, 8000), 2200)

        # Load, Render Space Station - "Base"(?)
        self.Spacestation1 = spaceJamClasses.SpaceStation(self.loader, "Assets/Space Station/SpaceStation1B/spaceStation.x", self.render, 'Spacestation1', (0, 2500, 3000), (15, 95, 200), 50)

        # Load, Render Space Ship - "Player"
        self.Spaceship = spaceJamClasses.SpaceShip(self.loader, "Assets/Spaceships/Dumbledore/Dumbledore.x", self.render, 'Spaceship1', (0, 50, 0), (0, 90, 0), 5)

        # Create drone defense paths
        fullCycle = 60

        for j in range(fullCycle):
            spaceJamClasses.Drone.droneCount += 1
            nickName = "Drone" + str(spaceJamClasses.Drone.droneCount)

            self.DrawCloudDefense(self.Planet1, nickName, 250, defensePaths.CloudX)
            self.DrawCloudDefense(self.Planet3, nickName, 1350, defensePaths.CloudY)
            self.DrawCloudDefense(self.Planet6, nickName, 2200, defensePaths.CloudZ)
            self.DrawBaseballSeams(self.Spacestation1, nickName, j, fullCycle, 2)


    # Create classes for drone Defense Paths behavior execution
    def DrawBaseballSeams(self, centralObject, droneName, step, numSeams, radius = 1):
        unitVec = defensePaths.baseBallSeams(step, numSeams, B = 0.4)
        unitVec.normalize()
        position = unitVec * radius * 250 + centralObject.modelNode.getPos()
        spaceJamClasses.Drone(self.loader, "Assets/DroneDefender/DroneDefender.obj", self.render, droneName, "Assets/DroneDefender/octotoad1_auv.png", position, 5)

    def DrawCloudDefense(self, centralObject, droneName, size, pathFunction = defensePaths.Cloud):
        unitVec = pathFunction()
        unitVec.normalize()
        position = unitVec * (size * 1.2) + centralObject.modelNode.getPos()
        spaceJamClasses.Drone(self.loader, "Assets/DroneDefender/DroneDefender.obj", self.render, droneName, "Assets/DroneDefender/octotoad1_auv.png", position, 10)


# Define 'main' class as app and run it when file is executed
app = mySpaceJam()
app.run()

